// ==UserScript==
// @name         img download
// @namespace    http://your.homepage/
// @version      1.0
// @description  test.
// @author       coffeecat
// @match        http*://*/*
// @icon         
// @grant        none
// ==/UserScript==
var p=document.createElement("button");
var t=document.getElementsByTagName("img");
var qw=0;
p.textContent="下載";
p.style="position:fixed;z-index:10000000;top:0%;right:0%;";
p.onmouseover=function(){
    var t=document.getElementsByTagName("img");
    p.title=t.length;
}
p.onclick=function asw(){
    var t=document.getElementsByTagName("img");
    var qa,wa;
    var i=qw;
    qw+=10;
    if(t.length==0){
        alert("none");
        qw-=10;
    }
    else if(qw>=t.length+10){
        alert("Done!");
        qw=t.length;
    }
    else if(qw>=t.length){
        alert("Wait!"+String(qw-9)+"~"+t.length+"/"+t.length);
    }
    else{
        alert("Wait!"+String(qw-9)+"~"+qw+"/"+t.length);
    }
    for(;i<t.length && i<qw;i++){
        qa=document.createElement("a");
        qa.href=t[i].src;
        qa.download="";
        qa.id="ta"+String(i);
        qa.target="_blank";
        qa.style="display:none;";
        document.body.append(qa);
        wa=document.getElementById("ta"+String(i));
        wa.click();
        wa.remove();
    }
}
setTimeout(function(){
    var t=document.getElementsByTagName("img");
    if(t.length==1){
        var qa,wa;
        qa=document.createElement("a");
        qa.href=t[0].src;
        qa.download="";
        qa.id="ta";
        qa.target="_blank";
        qa.style="display:none;";
        document.body.append(qa);
        wa=document.getElementById("ta");
        wa.click();
        wa.remove();
        close();
    }
},1000);
document.body.appendChild(p);
//setTimeout("alert('123');",5000);
/*
document.write("<style>.FPdoLc.lJ9FBc{background-color: red;}</style>");
function asdw(){
    document.getElementById("hpcta").click();
}
function qwse(){
    var a=document.getElementByName("btnI");
    for(var i=0;i<a.length;i++){
        a[i].value="123";
    }
}
setTimeout(asdw(),3000);
setTimeout(qwse(),5000);
*/