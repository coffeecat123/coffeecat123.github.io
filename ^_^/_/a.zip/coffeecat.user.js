// ==UserScript==
// @name         coffeecat
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  ^_^
// @author       coffeecat
// @match        http*://*/*
// @icon         
// @grant        none
// @noframes
// ==/UserScript==

(function() {
    'use strict';

    console.log("coffeecat");
    //var win = window.open("about:blank", "", "height=520,width=500");
    var _aa=document.createElement("div");
    var _ab=0;
    var _clr=document.createElement("input");
    _aa.append("background:",_clr,document.createElement("br"));
    var _dv=[
        ["字型",(function(){var c=["標楷體","新細明體","微軟正黑體","Arial","Arial Black","Verdana","Tahoma","Trebuchet MS","Impact","Times New Roman","Didot","Georgia","American Typewriter","Andalé Mono","Courier","Lucida Console","Monaco","Bradley Hand","Brush Script MT","Luminari","Comic Sans MS"];var b="";for(let i=0;i<c.length;i++){b+=`${i}:${c[i]}`;if(i<c.length-1)b+="\n";}b=prompt(b);if(b==null)return;if(isNaN(Number(b)))return;if(b%1!=0)return;if(b<0||b>=c)return;var a=document.querySelectorAll("*");for(let i=0;i<a.length;i++){a[i].style["font-family"]=c[b];}})
        ],
        ["180度旋轉",(function(){var e=document.querySelectorAll("video");for(let i=0;i<e.length;i++){if(!e[i].paused){if(e[i].style.transform=="rotate(180deg)"){e[i].style.transform+="rotate(0deg)";}else{e[i].style.transform+="rotate(180deg)";}}}})
        ],
        ["上下翻轉",(function(){var e=document.querySelectorAll("video");for(let i=0;i<e.length;i++){if(!e[i].paused){e[i].style.transform=="scaleY(-1)"?e[i].style.transform+="scaleY(1)":e[i].style.transform+="scaleY(-1)";}}})
        ],
        ["左右翻轉",(function(){var e=document.querySelectorAll("video");for(let i=0;i<e.length;i++){if(!e[i].paused){e[i].style.transform=="scaleX(-1)"?e[i].style.transform+="scaleX(1)":e[i].style.transform+="scaleX(-1)";}}})
        ],
        ["img",(function(){let cv=document.createElement('canvas');let c=cv.getContext('2d');let w=document.querySelectorAll("video");var z=0,x=0;for(var i=0;i<w.length;i++){if(w[i].offsetWidth>z&&w[i].style.display!="none"){z=w[i].offsetWidth;x=i;}}let vid=w[x];cv.width=vid.videoWidth;cv.height=vid.videoHeight;c.drawImage(vid,0,0);let a=document.body.appendChild(document.createElement('a'));a.href=cv.toDataURL();a.download='video截圖';a.click();a.remove();cv.remove();})
        ],
        ["full sc",(function(){let w=document.querySelectorAll("video");var z=0,x=0;for(var i=0;i<w.length;i++){if(w[i].offsetWidth>z&&w[i].style.display!="none"){z=w[i].offsetWidth;x=i;}}var elem=w[x];if(elem.requestFullscreen){elem.requestFullscreen();}else if(elem.msRequestFullscreen){elem.msRequestFullscreen();}else if(elem.mozRequestFullScreen){elem.mozRequestFullScreen();}else if(elem.webkitRequestFullscreen){elem.webkitRequestFullscreen();}})
        ],
        ["音量",(function(){var eq=100,wr=5;if(document.querySelectorAll("#coffeecat").length>0)return;var a=document.createElement("div");a.id="coffeecat";a.style=`user-select:none;-moz-user-select:none;-webkit-user-select:none;-ms-user-select:none;color:red;display:inline-block;top:0;left:0;position:fixed;z-index:1000000;`;document.body.append(a);setInterval(()=>{let s=document.querySelectorAll("audio,video");for(let i=0;i<s.length;i++){s[i].volume=eq / 100;a.textContent="volume : "+eq+"%";};},0);window.addEventListener("keydown",(k)=>{if(k.key=="ArrowUp"||k.key=="ArrowRight"){wsa(eq+wr);}if(k.key=="ArrowDown"||k.key=="ArrowLeft"){wsa(eq-wr);}});function wsa(sp){if(sp>=0&&sp<=100){eq=sp;}}})
        ],
        ["000webhost File Manager",(function(){document.querySelector("#code-editor").style.fontSize="25px";})
        ]];
    var _fm=document.createElement("iframe");
    _fm.width=500;
    _fm.height=100;
    _fm.setAttribute("allowfullscreen","");
    _fm.frameBorder='0';
    _fm.src='';
    var _yt=document.createElement("input");
    _yt.type="text";
    _yt.placeholder='YT link';
    _yt.style='font-size: 15px !important;border: 1px black solid;';
    _yt.onchange=()=>{
        let _a=_yt.value;
        if(_a.includes("https://www.youtube.com/watch?")){
            let _q=_a.split("watch?v=");
            _a=_q[0]+`embed/`+_q[1].split("&")[0];
        }
        _fm.src=_a;
    };
    for(let i=0;i<_dv.length;i++){
        let _bt=document.createElement("button");
        _bt.style='font-size: 15px !important;border: 1px black solid;height: 25px';
        _bt.textContent=_dv[i][0];
        _bt.onclick=()=>{
            _dv[i][1]();
        };
        _aa.append(_bt);
    }
    _aa.append(document.createElement("br"),_yt,_fm);
    _clr.type="color";
    _aa.style=`
    font-size: 30px;
    position: fixed;
    top: 0;
    left: 0;
    width: 500px;
    height: 300px;
    z-index: 123456789;
    display: none;
    color: white;
    background: rgb(0 0 0 / 80%);`;
    document.body.addEventListener("keydown",(k)=>{
        if(k.ctrlKey&&k.altKey&&k.key=='Backspace'){
            if(_ab){
                _aa.style.display="none";
            }
            else{
                _aa.style.display="block";
            }
            _ab^=1;
        }
    });
    _clr.onchange=()=>{
        _aa.style.background=_clr.value+"cc";
        if((parseInt(_clr.value.substr(1,2),16)+parseInt(_clr.value.substr(3,2),16)+parseInt(_clr.value.substr(5,2),16))/3>128){
            _aa.style.color="black";
        }
        else{
            _aa.style.color="white";
        }
    }
    document.body.insertBefore(_aa,document.body.firstChild);
})();