// ==UserScript==
// @name         YT ads X
// @namespace    ???
// @version      1.0
// @description  no ads
// @author       coffeecat
// @match        https://www.youtube.com/*
// @icon         
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    let a=location.href;
    start();
    setInterval(()=>{
        if(a!=location.href){
            a=location.href;
            setTimeout(start(),1000);
        }
    },1000);
    function start(){
        console.log("YT ads X");
        //---------https://www.youtube.com/watch?v=-----------
        if(location.href.indexOf("watch?v=")!=-1){
            setInterval(function q(){
                if(location.href.indexOf("watch?v=")==-1){
                    clearInterval(q);
                    return;
                }
                var cls=[".ytp-ad-overlay-slot",
                         ".ytp-ad-preview-slot",
                         ".style-scope ytd-watch-next-secondary-results-renderer sparkles-light-cta GoogleActiveViewElement",
                         ".style-scope ytd-companion-slot-renderer"
                        ,".ytp-ad-text.ytp-ad-message-text"
                        ,"div#contents>ytd-promoted-sparkles-web-renderer.style-scope.ytd-item-section-renderer.sparkles-light-cta"];
                for(let j=0;j<cls.length;j++){
                    var q=document.querySelectorAll(cls[j]);
                    for(let i=0;i<q.length;i++){
                        q[i].remove();
                        console.log("hide");
                    }
                }
                if(document.querySelectorAll(".video-ads.ytp-ad-module").length>0){
                    if(document.querySelector(".video-ads.ytp-ad-module").innerHTML!=''){
                        if(document.querySelectorAll(".ytp-ad-skip-button.ytp-button").length>0){
                            document.querySelectorAll(".ytp-ad-skip-button.ytp-button")[0].click();
                        }
                        if(document.querySelectorAll(".video-ads.ytp-ad-module .ytp-ad-duration-remaining").length>0){
                            document.querySelector("video").currentTime=document.querySelector("video").duration;
                        }
                        document.querySelector(".video-ads.ytp-ad-module").innerHTML='';
                    }
                }
            },1);
        }
        //------------https://www.youtube.com/-------------
        else if(location.href=="https://www.youtube.com/"){
            var i,t;
            //廣告
            //document.querySelector("input#search").value="";
            setInterval(function q(){
                if(location.href!="https://www.youtube.com/"){
                    clearInterval(q);
                    return;
                }
                var q=document.querySelectorAll("ytd-display-ad-renderer");
                for(i=0;i<q.length;i++){
                    q[i].offsetParent.remove();
                    console.log("hide");
                }
                var qa=document.getElementById("masthead-ad");
                if(qa!=null){
                    qa.remove();
                    console.log("hide");
                }
            },1);
        }
    };
})();